const API_BASE = 'https://your-backend.com/api';

export async function getUserProfile(userId) {
  const res = await fetch(`${API_BASE}/user/${userId}`);
  return res.json();
}

export async function getRecordings(userId) {
  const res = await fetch(`${API_BASE}/recordings/${userId}`);
  return res.json();
}